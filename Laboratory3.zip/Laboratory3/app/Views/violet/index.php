<?php include 'include/head.php' ?>

<body>
    <?php include 'include/preloder.php' ?>
    <?php include 'include/searchModel.php' ?>
    <?php include 'include/header.php' ?>
    <!-- <?php include 'include/headerInfo.php' ?> -->
    <?php include 'include/heroSlider.php' ?>
    <?php include 'include/features.php' ?>
    <?php include 'include/latest.php' ?>
    <!-- <?php include 'include/lookbok.php' ?> -->
    <?php include 'include/logo.php' ?>
    <?php include 'include/footer.php' ?>
    <?php include 'include/script.php' ?>
</body>
</html>