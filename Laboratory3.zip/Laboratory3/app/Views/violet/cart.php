<?php include 'include/head.php' ?>

<body>
    <?php include 'include/preloder.php' ?>
    <?php include 'include/searchModel.php' ?>
    <?php include 'include/header.php' ?>
    <?php include 'include/addCart.php' ?>
    <?php include 'include/cart.php' ?>
    <?php include 'include/logo.php' ?>
    <?php include 'include/footer.php' ?>
    <?php include 'include/script.php' ?>
</body>
</html>