<?php include 'include/head.php' ?>

<body>
    <?php include 'include/preloder.php' ?>
    <?php include 'include/searchModel.php' ?>
    <?php include 'include/header.php' ?>
    <?php include 'include/pageAdd.php' ?>
    <?php include 'include/categories.php' ?>
    <?php include 'include/footer.php' ?>
    <?php include 'include/script.php' ?>
</body>
</html>