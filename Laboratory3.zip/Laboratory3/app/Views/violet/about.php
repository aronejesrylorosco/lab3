<?php include 'include/head.php' ?>

<body>
    <?php include 'include/preloder.php' ?>
    <?php include 'include/searchModel.php' ?>
    <?php include 'include/header.php' ?>
    <?php include 'include/pageAdd.php' ?>
    <?php include 'include/product.php' ?>
    <?php include 'include/related.php' ?>
    <?php include 'include/lookbok.php' ?>
    <?php include 'include/logo.php' ?>
    <?php include 'include/footer.php' ?>
    <?php include 'include/script.php' ?>
</body>
</html>