<?php

namespace App\Controllers;

use App\Controllers\BaseController;

class MainController extends BaseController
{
    public function index()
    {
        return view('violet/index');
    }
    public function shop(){
        return view('violet/shop');
    }
    public function about(){
        return view('violet/about');
    }
    public function check(){
        return view('violet/checkOut');
    }
    public function contact(){
        return view('violet/contact');
    }
    public function cart(){
        return view('violet/cart');
    }
}
