<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'MainController::index');
$routes->get('/shop', 'MainController::shop');
$routes->get('/about', 'MainController::about');
$routes->get('/check', 'MainController::check');
$routes->get('/contact', 'MainController::contact');
$routes->get('/cart', 'MainController::cart');
